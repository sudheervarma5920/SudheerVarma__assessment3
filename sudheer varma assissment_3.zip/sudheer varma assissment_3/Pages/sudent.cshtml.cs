using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace sudheer_varma_assissment_3.Pages
{
    public class sudentModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
