using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using sudheer_varma_assissment_3.modeal;

namespace sudheer_varma_assissment_3.Pages
{
    public class StudentDetailsModel : PageModel
    {
        static List<Student> students = new List<Student> {
                new Student { StudentId = 1, Name = "vasu", Qualification = "B.Tech", Skill = "C#" },
                new Student { StudentId = 2, Name = "varma", Qualification = "b.Tech", Skill = "c#" },
                new Student { StudentId = 3, Name = "pavan", Qualification = "mba", Skill = "c#" }
            };

        [BindProperty]
        public Student Student { get; set; }
        public List<Student> List
        {

            get { return students; }
        }
        public void OnGet()
        {
        }
        public IActionResult OnPost()
        {
            students.Add(Student);
            return RedirectToPage("details");
        }

    }
}
